/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pkg1form;

/**
 *
 * @author user
 */
public class Studentdetails1 {
    private String jlnumber;
    private String name;

    public Studentdetails1(String jlnumber, String name) {
        this.jlnumber = jlnumber;
        this.name = name;
    }

    public String getJlnumber() {
        return jlnumber;
    }

    public void setJlnumber(String jlnumber) {
        this.jlnumber = jlnumber;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
                    
    
}
